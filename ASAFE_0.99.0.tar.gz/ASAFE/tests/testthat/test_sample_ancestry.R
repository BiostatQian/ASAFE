test_that("TESTING sample_ancestry()", {

    print("sample_ancestry(0) = Should be something other than 0")
    print(sample_ancestry(0))

    print("sample_ancestry(1) = Should be something other than 1")
    print(sample_ancestry(1))

    print("sample_ancestry(2) = Should be something other than 2")
    print(sample_ancestry(2))

})
